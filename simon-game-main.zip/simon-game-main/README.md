#Site is Live at
https://dainty-croissant-ace765.netlify.app

# simon-game
Simon Game is the short-term memory Skilled game. It creates a series of tones and the user has to repeat those tones in the same order.  As the level goes up the series becomes more complex and once he enters the worng sequnce or the time-limit runs out the Game is Over.
![2022-06-05 (3)](https://user-images.githubusercontent.com/76787669/172039217-9a8ac16e-468b-4783-9bc7-325b1b28f7e0.png)
